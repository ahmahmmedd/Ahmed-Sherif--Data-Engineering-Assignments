print("Banking Application Placeholder")
